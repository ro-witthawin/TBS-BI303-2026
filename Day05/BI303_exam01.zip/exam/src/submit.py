import os
import requests
import base64
import json
import platform
import re
import subprocess
import sys
import textwrap
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()
EXAM_ENDPOINT = os.getenv("EXAM_ENDPOINT")

class StudentExam:
    def __init__(self, student_id, fullname):
        self.student_id = student_id
        self.fullname = fullname
        self.meta = { 
            "student_id": student_id,
            "class": "BI303",
            "session": "810001"
        }
    def submit_exam1(self, obj_function):
        
        hidden_case = requests.get(f"{EXAM_ENDPOINT}/BI303/{self.student_id}/exam1/cases").json()

        for i in range(hidden_case):
            body_request = self.meta.copy()
            body_request["case_id"] = i
            hidden_content = requests.get(
                f"{EXAM_ENDPOINT}/BI303/{self.student_id}/exam1/request", 
                params=body_request).json()
            
            answer = obj_function(hidden_content["input"])

            body = requests.post(f"{EXAM_ENDPOINT}/BI303/{self.student_id}/exam1/check", 
                        json={"session_id": hidden_content["session_id"], "answer": answer}).json()

            print(f"Case {i} : {body['result']}")
            if body["result"] == "Fail":
                print(f"\tinput: '{hidden_content['input']}'")
                print(f"\tError: {body['error']}")
                

        content = requests.post(f"{EXAM_ENDPOINT}/BI303/{self.student_id}/exam1/submit", 
                                json={"student_id": self.student_id}).json()
        print(f"Submit: {content}")

    def submit_exam2(self, obj_function):
                
        hidden_case = requests.get(f"{EXAM_ENDPOINT}/BI303/{self.student_id}/exam2/cases").json()
        
        for i in range(hidden_case):
            body_request = self.meta.copy()
            body_request["case_id"] = i
            hidden_content = requests.get(
                f"{EXAM_ENDPOINT}/BI303/{self.student_id}/exam2/request", 
                params=body_request).json()
                    
            answer = obj_function(**hidden_content["input"])
        
            body = requests.post(f"{EXAM_ENDPOINT}/BI303/{self.student_id}/exam2/check", 
                json={"session_id": hidden_content["session_id"], "answer": answer}).json()
        
            print(f"Case {i} : {body['result']}")
            if body["result"] == "Fail":
                print(f"\tinput: '{hidden_content['input']}'")
                print(f"\tError: {body['error']}")
                        
        
        content = requests.post(f"{EXAM_ENDPOINT}/BI303/{self.student_id}/exam2/submit", 
                                        json={"student_id": self.student_id}).json()
        print(f"Submit: {content}")

    def submit_exam3(self, obj_function):
                    
        hidden_case = requests.get(f"{EXAM_ENDPOINT}/BI303/{self.student_id}/exam3/cases").json()
            
        for i in range(hidden_case):
            body_request = self.meta.copy()
            body_request["case_id"] = i
            hidden_content = requests.get(
                f"{EXAM_ENDPOINT}/BI303/{self.student_id}/exam3/request", 
                params=body_request).json()
                    
            answer = obj_function(hidden_content["input"])
        
            body = requests.post(f"{EXAM_ENDPOINT}/BI303/{self.student_id}/exam3/check", 
                json={"session_id": hidden_content["session_id"], "answer": answer}).json()
        
            print(f"Case {i} : {body['result']}")
            if body["result"] == "Fail":
                print(f"\tinput: '{hidden_content['input']}'")
                print(f"\tError: {body['error']}")
                        
        
        content = requests.post(f"{EXAM_ENDPOINT}/BI303/{self.student_id}/exam3/submit", 
                                        json={"student_id": self.student_id}).json()
        print(f"Submit: {content}")

    def submit_exam4(self, obj_function):
                        
        hidden_case = requests.get(f"{EXAM_ENDPOINT}/BI303/{self.student_id}/exam4/cases").json()
        
        for i in range(hidden_case):
            body_request = self.meta.copy()
            body_request["case_id"] = i
            hidden_content = requests.get(
                f"{EXAM_ENDPOINT}/BI303/{self.student_id}/exam4/request", 
                params=body_request).json()
                    
            answer = obj_function(hidden_content["input"])
        
            body = requests.post(f"{EXAM_ENDPOINT}/BI303/{self.student_id}/exam4/check", 
                json={"session_id": hidden_content["session_id"], "answer": answer}).json()
        
            print(f"Case {i} : {body['result']}")
            if body["result"] == "Fail":
                print(f"\tinput: '{hidden_content['input']}'")
                print(f"\tError: {body['error']}")
                        
        
        content = requests.post(f"{EXAM_ENDPOINT}/BI303/{self.student_id}/exam4/submit", 
                                        json={"student_id": self.student_id}).json()
        print(f"Submit: {content}")

    def submit_exam5(self, obj_function):
                        
        hidden_case = requests.get(f"{EXAM_ENDPOINT}/BI303/{self.student_id}/exam5/cases").json()
        
        for i in range(hidden_case):
            body_request = self.meta.copy()
            body_request["case_id"] = i
            hidden_content = requests.get(
                f"{EXAM_ENDPOINT}/BI303/{self.student_id}/exam5/request", 
                params=body_request).json()
                    
            answer = obj_function(hidden_content["input"])
        
            body = requests.post(f"{EXAM_ENDPOINT}/BI303/{self.student_id}/exam5/check", 
                json={"session_id": hidden_content["session_id"], "answer": answer}).json()
        
            print(f"Case {i} : {body['result']}")
            if body["result"] == "Fail":
                print(f"\tinput: '{hidden_content['input']}'")
                print(f"\tError: {body['error']}")
                        
        
        content = requests.post(f"{EXAM_ENDPOINT}/BI303/{self.student_id}/exam5/submit", 
                                        json={"student_id": self.student_id}).json()
        print(f"Submit: {content}")

    def check_summary_score(self):
        summarize_score = {}
        for i in range(5):
            meta_data = requests.get(f"{EXAM_ENDPOINT}/BI303/{self.student_id}/exam{i+1}/score", params={"student_id": self.student_id}).json()
            if "detail" in meta_data:
                summarize_score[f"exam_{i+1}"] = {
                    "score": 0,
                    "score_percent": 0,
                    "passed_checks": 0,
                    "total_cases": requests.get(f"{EXAM_ENDPOINT}/BI303/{self.student_id}/exam{i+1}/cases").json()
                }
            else:
                summarize_score[f"exam_{i+1}"] = {
                    "score": meta_data["score"]["score"],
                    "score_percent": meta_data["score"]["score_percent"],
                    "passed_checks": meta_data["score"]["passed_checks"],
                    "total_cases": meta_data["score"]["total_cases"]
                }
            print(f"Exam#{i+1}")
            print(f'\tScore: {summarize_score[f"exam_{i+1}"]["score"]}')
            print(f'\tPassed: {summarize_score[f"exam_{i+1}"]["passed_checks"]} / {summarize_score[f"exam_{i+1}"]["total_cases"]}')

        # return summarize_score

    def submit_notebook(self):
        notebook_path = Path.cwd() / "exam.ipynb"
        logs_dir = Path.cwd().parent / ".exam_logs"
        logs_dir.mkdir(parents=True, exist_ok=True)

        if not notebook_path.exists():
            raise FileNotFoundError(f"Notebook not found: {notebook_path}")

        student_for_upload = str(self.student_id or os.getenv("EXAM_STUDENT_ID") or "unknown").strip()
        student_for_upload = student_for_upload or "unknown"
        safe_student_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", student_for_upload).strip("._") or "unknown"
        run_id = datetime.now().strftime("%Y%m%d-%H%M%S")
        pdf_path = logs_dir / f"exam-{safe_student_id}-{run_id}.pdf"
        zip_path = logs_dir / f"exam-{safe_student_id}-{run_id}.zip"


        def export_pdf_with_nbconvert() -> tuple[bool, list[str]]:
            attempts = []
            exporters = [
                ("webpdf", ["--allow-chromium-download"]),
                ("pdf", []),
            ]
            for exporter, extra_args in exporters:
                command = [
                    sys.executable,
                    "-m",
                    "nbconvert",
                    "--to",
                    exporter,
                    "--output",
                    pdf_path.stem,
                    "--output-dir",
                    str(logs_dir),
                    str(notebook_path),
                    *extra_args,
                ]
                try:
                    result = subprocess.run(
                        command,
                        cwd=str(notebook_path.parent),
                        text=True,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT,
                        timeout=180,
                    )
                except Exception as exc:
                    attempts.append(f"{exporter}: {exc}")
                    continue

                if result.returncode == 0 and pdf_path.exists():
                    return True, attempts
                attempts.append(f"{exporter}: {result.stdout[-1200:]}")
            return False, attempts


        def notebook_lines_for_pdf() -> list[str]:
            nb = json.loads(notebook_path.read_text(encoding="utf-8"))
            lines = [
                "BI303 Exam Notebook Export",
                f"Student ID: {student_for_upload}",
                f"Full name: {self.fullname}",
                f"Exported at: {datetime.now().isoformat(timespec='seconds')}",
                f"Notebook: {notebook_path}",
            ]
            for index, cell in enumerate(nb.get("cells", []), start=1):
                source = "".join(cell.get("source", []))
                if not source.strip():
                    continue
                cell_type = str(cell.get("cell_type", "cell")).upper()
                prefix = "    " if cell_type == "CODE" else ""
                lines.extend(["", f"[{index}] {cell_type}"])
                for raw_line in source.splitlines():
                    wrapped = textwrap.wrap(
                        raw_line.replace("\t", "    "),
                        width=88,
                        replace_whitespace=False,
                        drop_whitespace=False,
                    ) or [""]
                    lines.extend(prefix + part for part in wrapped)
            return lines


        def pdf_escape(value: str) -> str:
            return value.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


        def write_text_pdf(path: Path, lines: list[str]) -> None:
            page_width = 612
            page_height = 792
            margin = 46
            line_height = 11
            max_lines = int((page_height - (margin * 2)) / line_height)
            pages = [lines[i : i + max_lines] for i in range(0, len(lines), max_lines)] or [[""]]

            objects: dict[int, bytes] = {
                1: b"<< /Type /Catalog /Pages 2 0 R >>",
                3: b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
            }
            page_ids = []
            next_id = 4
            for page_lines in pages:
                content_id = next_id
                page_id = next_id + 1
                next_id += 2
                page_ids.append(page_id)
                commands = ["BT", "/F1 9 Tf", f"{margin} {page_height - margin} Td", f"{line_height} TL"]
                for line in page_lines:
                    commands.append(f"({pdf_escape(line[:120])}) Tj")
                    commands.append("T*")
                commands.append("ET")
                stream = "\n".join(commands).encode("latin-1", "replace")
                objects[content_id] = b"<< /Length " + str(len(stream)).encode("ascii") + b" >>\nstream\n" + stream + b"\nendstream"
                objects[page_id] = (
                    f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {page_width} {page_height}] "
                    f"/Resources << /Font << /F1 3 0 R >> >> /Contents {content_id} 0 R >>"
                ).encode("ascii")

            kids = " ".join(f"{page_id} 0 R" for page_id in page_ids)
            objects[2] = f"<< /Type /Pages /Kids [{kids}] /Count {len(page_ids)} >>".encode("ascii")

            pdf = bytearray(b"%PDF-1.4\n")
            offsets = [0] * (max(objects) + 1)
            for obj_id in range(1, max(objects) + 1):
                offsets[obj_id] = len(pdf)
                pdf.extend(f"{obj_id} 0 obj\n".encode("ascii"))
                pdf.extend(objects[obj_id])
                pdf.extend(b"\nendobj\n")
            xref_at = len(pdf)
            pdf.extend(f"xref\n0 {len(offsets)}\n0000000000 65535 f \n".encode("ascii"))
            for offset in offsets[1:]:
                pdf.extend(f"{offset:010d} 00000 n \n".encode("ascii"))
            pdf.extend(
                f"trailer\n<< /Size {len(offsets)} /Root 1 0 R >>\nstartxref\n{xref_at}\n%%EOF\n".encode("ascii")
            )
            path.write_bytes(pdf)

        exported_with_nbconvert, export_attempts = export_pdf_with_nbconvert()
        if not exported_with_nbconvert:
            write_text_pdf(pdf_path, notebook_lines_for_pdf())

        manifest = {
            "student_id": student_for_upload,
            "fullname": self.fullname,
            "run_id": run_id,
            "notebook": notebook_path.name,
            "pdf": pdf_path.name,
            "logs": [],
            "pdf_exporter": "nbconvert" if exported_with_nbconvert else "text-pdf-fallback",
            "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "nbconvert_attempts": export_attempts,
        }

        log_files = sorted(
            path
            for path in logs_dir.glob("*.log")
            if path.is_file() and path.resolve() not in {pdf_path.resolve(), zip_path.resolve()}
        )
        manifest["logs"] = [path.name for path in log_files]

        with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.write(notebook_path, arcname=notebook_path.name)
            archive.write(pdf_path, arcname=pdf_path.name)
            for log_file in log_files:
                archive.write(log_file, arcname=f"logs/{log_file.name}")
            archive.writestr("manifest.json", json.dumps(manifest, indent=2))

        api_url = os.getenv("EXAM_LOG_API", "").strip()
        exam_endpoint = os.getenv("EXAM_ENDPOINT", "").strip()
        if not api_url and exam_endpoint:
            api_url = exam_endpoint.rstrip("/") + "/exam/logs"
        api_url = api_url.replace("://0.0.0.0", "://127.0.0.1", 1)

        if not api_url:
            raise RuntimeError("Set EXAM_LOG_API or EXAM_ENDPOINT before uploading the exam archive.")

        archive_b64 = base64.b64encode(zip_path.read_bytes()).decode("ascii")
        payload = {
            "run_id": f"notebook-export-{run_id}",
            "student_id": student_for_upload,
            "machine_id": str(uuid.getnode()),
            "platform": platform.platform(),
            "ended_at": datetime.now().isoformat(timespec="seconds"),
            "archive_filename": zip_path.name,
            "archive_size_bytes": zip_path.stat().st_size,
            "logs": {
                "notebook_export_manifest": json.dumps(manifest, indent=2),
                "notebook_export_zip_base64": archive_b64,
            },
        }
        headers = {"Content-Type": "application/json"}
        api_token = os.getenv("EXAM_LOG_API_TOKEN", "").strip()
        if api_token:
            headers["Authorization"] = f"Bearer {api_token}"

        response = requests.post(api_url, json=payload, headers=headers, timeout=60)
        response.raise_for_status()
        response_content = (
            response.json()
            if response.headers.get("content-type", "").startswith("application/json")
            else response.text
        )

        pdf_path.unlink(missing_ok=True)
        zip_path.unlink(missing_ok=True)